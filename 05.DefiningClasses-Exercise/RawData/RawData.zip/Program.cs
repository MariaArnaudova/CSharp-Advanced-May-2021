﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RawData
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            //"{model} {engineSpeed} {enginePower} {cargoWeight} {cargoType} {tire1Pressure} {tire1Age} 
            //{tire2Pressure} {tire2Age} {tire3Pressure} {tire3Age} {tire4Pressure} {tire4Age}"
            List<Car> cars = new List<Car>();

            for (int i = 0; i < n; i++)
            {
                string[] carInfo = Console.ReadLine().Split();

                string model = carInfo[0];
                int engineSpeed = int.Parse(carInfo[1]);
                int enginePower = int.Parse(carInfo[2]);
                int cargoWeight = int.Parse(carInfo[3]);
                string cargoType = carInfo[4];
                double tire1Pressure = double.Parse(carInfo[5]);
                int tire1Age = int.Parse(carInfo[6]);
                double tire2Pressure = double.Parse(carInfo[7]);
                int tire2Age = int.Parse(carInfo[8]);
                double tire3Pressure = double.Parse(carInfo[9]);
                int tire3Age = int.Parse(carInfo[10]);
                double tire4Pressure = double.Parse(carInfo[11]);
                int tire4Age = int.Parse(carInfo[12]);

                Engine engine = new Engine(engineSpeed, enginePower);
                Cargo cargo = new Cargo(cargoWeight, cargoType);
                Tire[] tires = new Tire[4];
                int countTires = 0;

                for (int j = 5; j < carInfo.Length; j += 2)
                {
                    double tirePressure = double.Parse(carInfo[j]);
                    int tireAge = int.Parse(carInfo[j + 1]);
                    Tire newTire = new Tire(tirePressure, tireAge);
                    tires[countTires++] = newTire;
                }

                //tires[0].Pressure = tire1Pressure;
                //tires[0].Age = tire1Age;
                //tires[1].Pressure = tire2Pressure;
                //tires[1].Age = tire2Age;
                //tires[2].Pressure = tire3Pressure;
                //tires[2].Age = tire3Age;
                //tires[3].Pressure = tire4Pressure;
                //tires[3].Age = tire4Age;

                Car car = new Car(model, engine, cargo, tires);
                cars.Add(car);
            }

            string command = Console.ReadLine();

            if (command == "fragile")
            {
                cars = cars.Where(c => c.Cargo.Type == "fragile"
                && c.Tires.Any(tire =>tire.Pressure<1)).ToList();
                foreach (var car in cars)
                {
                    Console.WriteLine($"{car.Model}");
                }
            }
            else if (command == "flamable")
            {
                cars = cars.Where(c => c.Engine.Power > 250).ToList();
                foreach (var car in cars)
                {
                    Console.WriteLine($"{car.Model}");
                }
            }
        }
    }
}
